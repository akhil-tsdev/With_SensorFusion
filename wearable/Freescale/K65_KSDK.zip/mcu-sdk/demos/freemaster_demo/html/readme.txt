FreeMASTER Serial Communication Driver
======================================

This folder contains HTML resources for FreeMASTER pages displayed in demo project.

----
Copyright 2004-2013, Freescale Inc.
ALL RIGHTS RESERVED, www.freescale.com
