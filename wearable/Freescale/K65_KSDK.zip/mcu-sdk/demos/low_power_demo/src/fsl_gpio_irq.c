/*
 * Copyright (c) 2013 - 2014, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <assert.h>
#include <stdio.h>
#include "fsl_gpio_driver.h"

extern uint8_t uartEnabled;

/*******************************************************************************
 * Code
 ******************************************************************************/
#if defined (KL25Z4_SERIES) || defined (K64F12_SERIES) ||\
    defined (K70F12_SERIES) || defined (K22F51212_SERIES)|| \
    defined (KV31F51212_SERIES) || defined (K22F25612_SERIES) || \
    defined (K22F12810_SERIES) || defined (KV31F25612_SERIES) || defined (KV31F12810_SERIES)
/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTA_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTA_BASE);
    
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT interrupt ISR! --\n\n\r");
    }
}

/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTD_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTD_BASE);
    
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT interrupt ISR! --\n\n\r");
    }
}

#if defined (K64F12_SERIES) || defined (K22F51212_SERIES) || defined (K70F12_SERIES)|| \
    defined (KV31F51212_SERIES) || defined (K22F25612_SERIES) || defined (K22F12810_SERIES) || \
    defined (KV31F25612_SERIES) || defined (KV31F12810_SERIES)

/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTB_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTB_BASE);
    
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT B interrupt ISR! --\n\n\r");
    }
}

/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTC_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTC_BASE);
    
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT C interrupt ISR! --\n\n\r");
    }
}

/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTE_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTE_BASE);
    
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT interrupt ISR! --\n\n\r");
    }
}

#if defined (K70F12_SERIES)
/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTF_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTF_BASE);
    
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT interrupt ISR! --\n\n\r");
    }
}
#endif

#endif

#endif

#if defined(KV10Z7_SERIES)
/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTA_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTA_BASE);
    
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT interrupt ISR! --\n\n\r");
    }
}
/*
 * gpio IRQ handler with the same name in startup code
 */
void PORTBCDE_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    PORT_HAL_ClearPortIntFlag(PORTB_BASE);
    PORT_HAL_ClearPortIntFlag(PORTC_BASE);
    PORT_HAL_ClearPortIntFlag(PORTD_BASE);
    PORT_HAL_ClearPortIntFlag(PORTE_BASE);
	
    if (uartEnabled)
    {
        printf("\n\n\r-- Entered PORT interrupt ISR! --\n\n\r");
    }
}
#endif

/*! @} */

/*******************************************************************************
 * EOF
 ******************************************************************************/

