#!/bin/sh
rm -rf Debug Release CMakeFiles
rm -rf Makefile cmake_install.cmake CMakeCache.txt
