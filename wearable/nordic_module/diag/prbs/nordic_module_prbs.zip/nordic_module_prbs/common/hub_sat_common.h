/*******************************************************************
 * Copyright (c) Turingsense 2016
 *
 * hub_sat_common.h
 *
 * Jan 13, 2016
 *******************************************************************/
#ifndef __HUB_SAT_COMMON_H__
#define __HUB_SAT_COMMON_H__

bool rx_from_hub_is_valid(hts_packet_t* packet);
bool rx_from_sat_is_valid(sth_packet_t* packet);
void set_sat_idx(uint32_t num_of_sat, uint32_t satellite_ids[MAX_SAT_SENSORS]);
uint8_t get_sat_idx(uint32_t sat_ID);

#endif /* __HUB_SAT_COMMON_H__ */
