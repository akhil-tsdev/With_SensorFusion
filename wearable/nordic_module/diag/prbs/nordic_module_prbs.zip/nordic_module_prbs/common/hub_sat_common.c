/*******************************************************************
 * Copyright (c) Turingsense 2016
 *
 * hub_sat_common.c
 * Common code shared by hub & sat
 *
 * Jan 13, 2016
 *******************************************************************/

#if MINI_HUB_NORDIC
#include "mini_hub_main.h"
#endif

#include "crc16.h"
#include "crc32.h"
#include "hub_sat_common.h"
#include "net_common.h"
 
bool rx_from_hub_is_valid(hts_packet_t* packet) {
	// Only interested in packets from our own hub.
	if(packet->header.sender != my_hub_id) {
		return false;
	}
	// Check that the control packet hasn't been corrupted.
	hts_payload_t payload = packet->hts_payload;
	uint32_t sent_crc32 = payload.command_crc32;
	payload.command_crc32 = 0;
	uint32_t calculated_crc32 = crc32(0xFFFFFFFF, &payload,
																 sizeof(payload));
	return (calculated_crc32 == sent_crc32);
}

bool rx_from_sat_is_valid(sth_packet_t* packet) {
	uint16_t pattern = packet->satellite_to_hub_payload.diagnostic_pattern1;
	pattern =  (pattern<<8) +  packet->satellite_to_hub_payload.diagnostic_pattern2;

	// Only pay attention to satellites we know about.
	// TODO: this should instead use the list of registered satellite IDs from
	// the Freescale.
	if(get_sat_idx(packet->header.sender) == INVALID_SAT_IDX) {
		return false;
	}
//	
//	// We always expect to get a reply back from the same satellite that we
//	// contacted. If not, it's a sign that something is very delayed on the
//	// satellite - it's taking more than 5ms to respond to our request! Make
//	// note of that for diagnostic purposes.
//	if(packet->header.sender != cur_sat_ids[target_sat_idx]) {
//		ct_out_of_turn ++;
//	}
	
	uint32_t payload_timestamp = packet->satellite_to_hub_payload.header.timestamp;
	uint16_t timestamp_crc = crc16_compute((uint8_t*)(&payload_timestamp),sizeof(payload_timestamp),0);
	
	return packet->satellite_to_hub_payload.header.timestamp_crc == timestamp_crc;	
}

/* 
 * Sat ID is the 32-bit Hardware ID assigned for each satellite hardware.
 * It's sort of like a MAC address, stays with the hardware throughout its
 * life.
 *
 * On the other hand, sat_idx is the index of this satellite that this
 * hub is concerned with.
 *
 * For example:
 * A user might at one recording uses:
*   sat_idx 0: sat ID 0x0
*   sat_idx 1: sat ID 0xbbccbbcc
*   sat_idx 2: sat ID 0x8
*  
*  on another recording, the user switches the satellite so that:
*
*   sat_idx 0: sat ID 0xbbccbbcc
*   sat_idx 1: sat ID 0x0
*   sat_idx 2: sat ID 0x8
*
* Return:		sat_idx - index of the satellite ID
*						0xFFFFFFFF (a.k.a INVALID_SAT_ID) - if not found
*/ 
uint8_t get_sat_idx(uint32_t sat_ID) {
	uint8_t sat_idx = INVALID_SAT_IDX;
	
	for (uint8_t idx = 0; idx < cur_num_of_sat; idx++) {
		if (cur_sat_ids[idx] == sat_ID) {
			sat_idx = idx;
			break;
		}
	}
	
	return sat_idx;
}

void set_sat_idx(uint32_t num_of_sat, uint32_t satellite_ids[MAX_SAT_SENSORS]) {
	uint8_t cnt;
	
	cur_num_of_sat = num_of_sat;
	
	for (cnt = 0; cnt < MAX_SAT_SENSORS; cnt++) {
		if (cnt < cur_num_of_sat) {
			cur_sat_ids[cnt] = satellite_ids[cnt];
		} else {
			cur_sat_ids[cnt] = INVALID_SAT_ID;
		}
	}
}
