/* Copyright (c) 2016 Turingsense
 *
 * January 25th, 2016
 *
 * prbs.h
 *
 */

#ifndef __PRBS_H__
#define __PRBS_H__

uint8_t prbs7(void);
uint16_t prbs15(void);
uint32_t prbs23(void);
uint32_t prbs31(void);

#endif /* __PRBS_H__ */
