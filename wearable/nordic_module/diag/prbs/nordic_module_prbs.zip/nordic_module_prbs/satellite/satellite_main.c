/* Copyright (c) 2016 Turingsense Inc
 * 
 * Jan 25, 2016
 *
 * This satellite code will send 32-bit PRBS continuously.  That's all it does.
 */
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "app_util.h"
#include "nrf.h"
#include "uesb/micro_esb.h"
#include "uesb/uesb_error_codes.h"

#include "net_common.h"

#include "crc32.h"
#include "boards.h"
#include "nrf_gpio.h"
#include "simple_uart.h"
//#include "fifo.h"
#include "crc16.h"
#include "nrf_delay.h"
#include "led_trace.h"
#include "prbs.h"

//Bill --> CHANGE ME for frequency
//The nordic chip supports frequencies from 2.400 GHz to 2.526 GHz. 
//These are described as "channels" 0 - 126, with each channel having a 1MHz band.
//In the USA, only the frequency range of 2,400�2,483.5 MHz is permitted
//for unlicensed use. In other words, channels 0-83 only.
uint32_t tx_freq = 0;
uint32_t rx_freq = 3;

void satellite_rx_handler(uint32_t packet) {
	;//dummy do nothing
}

static void reinit_esb() {
	net_init(satellite_rx_handler, 0, tx_freq, rx_freq);
}

static void ui_init(void)
{
	uint32_t buttons[] = BUTTONS_LIST;
	uint32_t leds[] = LEDS_LIST;
	uint32_t i;

	for (i = 0; i < BUTTONS_NUMBER; i++)
	{
			nrf_gpio_cfg_input(buttons[i],NRF_GPIO_PIN_PULLUP);
	}
	for (i = 0; i < LEDS_NUMBER; i++)
	{
			nrf_gpio_cfg_output(leds[i]);
	}
	//simple_uart_config(RTS_PIN_NUMBER, TX_PIN_NUMBER, CTS_PIN_NUMBER, RX_PIN_NUMBER, HWFC);
}


/// Replies to the hub with the currently prepared data payload. Blocks until sending is over.
void send_packet_to_hub(void) {
	uint32_t sth_packet;
	
	sth_packet = prbs31();

	send_packet(sth_packet);
	int timeout_10us = 0;
	while(fate_of_last_tx == TX_FATE_UNKNOWN) {
		nrf_delay_us(10);
		timeout_10us++;
		if(timeout_10us > 1000) {
			// It's been 10ms. Assume something went wrong. 
			
			// Reset the RF library since we can't know if state is still good.
			reinit_esb();
			uesb_start_rx();
			break;
		}
	}

}

int main(void)
{
    // Set 16 MHz crystal as our 16 MHz clock source (as opposed to internal RCOSC)
    NRF_CLOCK->EVENTS_HFCLKSTARTED = 0;
    NRF_CLOCK->TASKS_HFCLKSTART = 1;
    while(NRF_CLOCK->EVENTS_HFCLKSTARTED == 0)
    {
        // Wait
    }
		
		//Sometimes after power up, 22F is not ready, let's wait for 1 second.
		nrf_delay_us(100000);

    ui_init();
		
		reinit_esb();
    uesb_start_rx();

    while (true)
    {   
			send_packet_to_hub();
    }

}
