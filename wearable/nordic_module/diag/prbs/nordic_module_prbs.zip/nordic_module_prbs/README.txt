/* Copyright (c) Turingsense
 * 
 * Jan 25th, 2016
 *
 * README.txt
 *
 */

This folder contains standalone project for Bill.
The satellite is sending PRBS31 continuously.

If you want to change the channel for the satellite, open satellite_main.c
then edit the tx_freq & rx_freq.

I provided nordic_module\diag\spi\hub_not_talking_to_22f which is a hub eval
project that can be used on NRF51422 to print to COMPORT the value it received
from satellite.
You should also modify in the hub_main.c the "tx_freq" & "rx_freq" if you want
the hub to talk to a specific satellite.

Note:
Satellite rx_freq MUST EQUAL to hub tx_freq.  Vice versa,
Satellite tx_freq MUST EQUAL to hub rx_freq.
