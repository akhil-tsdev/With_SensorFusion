11/12/15
This Nordic is receiving data from satellites and output it to python/printf.
This is to test communication between nordic hub & nordic satellites.
